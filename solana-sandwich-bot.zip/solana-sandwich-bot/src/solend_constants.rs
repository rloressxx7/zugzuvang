// Solend Protocol Constants and PDA Derivation
// For flash loan integration with MEV bot

use anyhow::{Context, Result};
use borsh::{BorshDeserialize, BorshSerialize};
use solana_sdk::pubkey::Pubkey;

/// Solend program ID (mainnet)
pub const SOLEND_PROGRAM_ID: &str = "9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin";

/// Solend flash loan instruction discriminator (from IDL)
/// NOTE: This is a placeholder - actual discriminator from Solend IDL
pub const FLASH_LOAN_DISCRIMINATOR: [u8; 8] = [0x18, 0x3d, 0xf3, 0x9c, 0x4a, 0x5f, 0x7a, 0x3d];

/// Solend flash loan receive discriminator (callback)
pub const FLASH_LOAN_RECEIVE_DISCRIMINATOR: [u8; 8] = [0x0c, 0x2a, 0x3f, 0x8d, 0x7e, 0x6f, 0x4b, 0x9c];

/// Solend flash loan repay discriminator
pub const FLASH_LOAN_REPAY_DISCRIMINATOR: [u8; 8] = [0x1a, 0x4b, 0x5c, 0x6d, 0x7e, 0x8f, 0x9a, 0x0b];

/// Flash loan fee (basis points) - typically 0.08% = 8 bps
pub const FLASH_LOAN_FEE_BPS: u64 = 8;

/// Solend market accounts (SOL market)
pub const SOLEND_MARKET_AUTHORITY: &str = "8sJJ5TwzTQ5zGhfnRt55fZHHW2nNReqYdQoBqk2yPNNk";
pub const SOLEND_LENDING_MARKET: &str = "9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin";

/// SOL reserve (for flash loan)
/// This is the reserve account for SOL (lamports)
/// NOTE: Actual address needs to be derived from Solend market
pub const SOLEND_SOL_RESERVE: &str = "So1endDq2YkqhipRh3WViPa8hdiSpxWy6U3d6hoQ5R8F";

/// Solend flash loan callback program
pub const FLASH_LOAN_CALLBACK_PROGRAM: &str = "FLCb1111111111111111111111111111111111111111";

/// Solend flash loan data
#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct FlashLoanData {
    pub amount: u64,
    pub receiver_program: Pubkey,
    pub padding: [u64; 4],
}

/// Solend flash loan receive data (callback)
#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct FlashLoanReceiveData {
    pub repay_amount: u64,
    pub padding: [u64; 4],
}

/// Get Solend reserve PDA
pub fn find_solend_reserve(lending_market: &Pubkey, token_mint: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[b"reserve", lending_market.as_ref(), token_mint.as_ref()],
        &SOLEND_PROGRAM_ID.parse().unwrap(),
    )
}

/// Get Solend market authority
pub fn find_solend_market_authority(lending_market: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[b"lending-market", lending_market.as_ref()],
        &SOLEND_PROGRAM_ID.parse().unwrap(),
    )
}

/// Get Solend obligation account
pub fn find_solend_obligation(lending_market: &Pubkey, owner: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[b"obligation", lending_market.as_ref(), owner.as_ref()],
        &SOLEND_PROGRAM_ID.parse().unwrap(),
    )
}

/// Calculate flash loan repayment amount
/// loan_amount + (loan_amount * fee_bps / 10000)
pub fn calculate_repayment(loan_amount: u64, fee_bps: u64) -> u64 {
    let fee = (loan_amount as u128 * fee_bps as u128 / 10000) as u64;
    loan_amount + fee
}

#[cfg(test)]
mod tests {
    use super::*;
    use solana_sdk::signature::Keypair;
    
    #[test]
    fn test_solend_constants() {
        // Verify discriminator placeholders are not default
        assert_ne!(FLASH_LOAN_DISCRIMINATOR, [0u8; 8]);
        assert!(FLASH_LOAN_FEE_BPS <= 100);
    }
    
    #[test]
    fn test_repayment_calculation() {
        let loan = 1_000_000_000; // 1 SOL
        let fee = 8; // 0.08%
        let repay = calculate_repayment(loan, fee);
        assert_eq!(repay, loan + (loan * fee / 10000));
    }
}