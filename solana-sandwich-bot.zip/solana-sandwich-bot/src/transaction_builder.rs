use anyhow::Result;
use solana_program::instruction::{AccountMeta, Instruction};
use solana_sdk::{pubkey::Pubkey, system_program};

use crate::pump_idl::{BUY_DISCRIMINATOR, PUMP_FUN_PROGRAM_ID, SELL_DISCRIMINATOR};
use crate::token::{get_associated_token_address, token_program_id};

/// Pump.fun program ID
pub fn pump_fun_program_id() -> Pubkey {
    PUMP_FUN_PROGRAM_ID.parse().unwrap()
}

/// Global account
pub fn global_account() -> Pubkey {
    "4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5WKy2b4JFKaxnjf".parse().unwrap()
}

/// Fee recipient (from global)
pub fn fee_recipient() -> Pubkey {
    "CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM".parse().unwrap()
}

/// Pump.fun event authority
pub fn event_authority() -> Pubkey {
    "Ce6TQqeHC9p8KetsN6JsjHK7UTZk7nasjjnr7XxXp9F1".parse().unwrap()
}

/// Build Pump.fun buy instruction
pub fn create_pump_buy_ix(
    buyer: &Pubkey,
    mint: &Pubkey,
    bonding_curve: &Pubkey,
    associated_bonding_curve: &Pubkey,
    amount: u64,       // Max SOL to spend (lamports)
    max_sol_cost: u64, // Max SOL cost (lamports) - for slippage
) -> Result<Instruction> {
    let program_id = pump_fun_program_id();
    let global = global_account();
    let fee_recipient = fee_recipient();
    let event_auth = event_authority();

    // Buyer's ATA for the token
    let buyer_ata = get_associated_token_address(buyer, mint);

    // Instruction data: discriminator + amount + max_sol_cost
    let mut data = Vec::with_capacity(8 + 8 + 8);
    data.extend_from_slice(&BUY_DISCRIMINATOR);
    data.extend_from_slice(&amount.to_le_bytes());
    data.extend_from_slice(&max_sol_cost.to_le_bytes());

    let accounts = vec![
        AccountMeta::new(global, false),
        AccountMeta::new(fee_recipient, false),
        AccountMeta::new_readonly(*mint, false),
        AccountMeta::new(*bonding_curve, false),
        AccountMeta::new(*associated_bonding_curve, false),
        AccountMeta::new(buyer_ata, false),
        AccountMeta::new(*buyer, true),
        AccountMeta::new_readonly(system_program::id(), false),
        AccountMeta::new_readonly(token_program_id(), false),
        AccountMeta::new_readonly(event_auth, false),
        AccountMeta::new_readonly(program_id, false),
    ];

    Ok(Instruction {
        program_id,
        accounts,
        data,
    })
}

/// Build Pump.fun sell instruction
pub fn create_pump_sell_ix(
    seller: &Pubkey,
    mint: &Pubkey,
    bonding_curve: &Pubkey,
    associated_bonding_curve: &Pubkey,
    amount: u64,         // Token amount to sell
    min_sol_output: u64, // Minimum SOL to receive (lamports)
) -> Result<Instruction> {
    let program_id = pump_fun_program_id();
    let global = global_account();
    let fee_recipient = fee_recipient();
    let event_auth = event_authority();

    // Seller's ATA for the token
    let seller_ata = get_associated_token_address(seller, mint);

    // Instruction data: discriminator + amount + min_sol_output
    let mut data = Vec::with_capacity(8 + 8 + 8);
    data.extend_from_slice(&SELL_DISCRIMINATOR);
    data.extend_from_slice(&amount.to_le_bytes());
    data.extend_from_slice(&min_sol_output.to_le_bytes());

    let accounts = vec![
        AccountMeta::new(global, false),
        AccountMeta::new(fee_recipient, false),
        AccountMeta::new_readonly(*mint, false),
        AccountMeta::new(*bonding_curve, false),
        AccountMeta::new(*associated_bonding_curve, false),
        AccountMeta::new(seller_ata, false),
        AccountMeta::new(*seller, true),
        AccountMeta::new_readonly(system_program::id(), false),
        AccountMeta::new_readonly(token_program_id(), false),
        AccountMeta::new_readonly(event_auth, false),
        AccountMeta::new_readonly(program_id, false),
    ];

    Ok(Instruction {
        program_id,
        accounts,
        data,
    })
}

/// Derive bonding curve PDA for a mint
pub fn find_bonding_curve(mint: &Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(
        &[b"bonding-curve", mint.as_ref()],
        &pump_fun_program_id(),
    )
}

/// Derive associated bonding curve ATA
pub fn find_associated_bonding_curve(mint: &Pubkey, bonding_curve: &Pubkey) -> Pubkey {
    get_associated_token_address(bonding_curve, mint)
}

/// Build complete front-run + back-run transaction pair
pub fn build_sandwich_tx(
    wallet: &Pubkey,
    mint: &Pubkey,
    bonding_curve: &Pubkey,
    associated_bonding_curve: &Pubkey,
    front_run_sol: u64,     // SOL to spend on front-run buy
    front_run_max_sol: u64, // Max SOL for front-run (slippage)
    back_run_tokens: u64,   // Tokens to sell in back-run
    back_run_min_sol: u64,  // Min SOL from back-run
) -> Result<(Instruction, Instruction)> {
    let front_run = create_pump_buy_ix(
        wallet,
        mint,
        bonding_curve,
        associated_bonding_curve,
        front_run_sol,
        front_run_max_sol,
    )?;

    let back_run = create_pump_sell_ix(
        wallet,
        mint,
        bonding_curve,
        associated_bonding_curve,
        back_run_tokens,
        back_run_min_sol,
    )?;

    Ok((front_run, back_run))
}

#[cfg(test)]
mod tests {
    use super::*;
    use solana_sdk::signature::Keypair;
    use solana_sdk::signer::Signer;

    #[test]
    fn test_pda_derivation() {
        let mint = Keypair::new().pubkey();
        let (curve, bump) = find_bonding_curve(&mint);
        let ata = find_associated_bonding_curve(&mint, &curve);

        assert_ne!(curve, Pubkey::default());
        assert_ne!(ata, Pubkey::default());
        println!("Curve: {}, bump: {}, ATA: {}", curve, bump, ata);
    }
}
