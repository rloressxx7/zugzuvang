use anyhow::Result;
use borsh::{BorshDeserialize, BorshSerialize};
use solana_sdk::pubkey::Pubkey;

/// Pump.fun program ID
pub const PUMP_FUN_PROGRAM_ID: &str = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P";

/// Global account - stores protocol fees, etc.
pub const GLOBAL_ACCOUNT: &str = "4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5WKy2b4JFKaxnjf";

/// Pump.fun buy instruction discriminator: "buy" -> [0x66, 0x06, 0x3d, 0x12, 0x01, 0xda, 0xeb, 0xea]
pub const BUY_DISCRIMINATOR: [u8; 8] = [0x66, 0x06, 0x3d, 0x12, 0x01, 0xda, 0xeb, 0xea];

/// Pump.fun sell instruction discriminator: "sell" -> [0x33, 0xe6, 0x85, 0xa4, 0x01, 0x7f, 0x83, 0xad]
pub const SELL_DISCRIMINATOR: [u8; 8] = [0x33, 0xe6, 0x85, 0xa4, 0x01, 0x7f, 0x83, 0xad];

/// Pump.fun create instruction discriminator
pub const CREATE_DISCRIMINATOR: [u8; 8] = [0x18, 0x1e, 0xc8, 0x28, 0x05, 0x1c, 0x07, 0x77];

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct BuyInstructionData {
    pub amount: u64,      // Maximum SOL to spend (in lamports)
    pub max_sol_cost: u64, // Maximum SOL cost (redundant, for safety)
}

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct SellInstructionData {
    pub amount: u64,      // Token amount to sell
    pub min_sol_output: u64, // Minimum SOL to receive
}

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct CreateInstructionData {
    pub name: String,
    pub symbol: String,
    pub uri: String,
}

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct GlobalState {
    pub initialized: bool,
    pub authority: Pubkey,
    pub fee_recipient: Pubkey,
    pub initial_virtual_token_reserves: u64,
    pub initial_virtual_sol_reserves: u64,
    pub initial_real_token_reserves: u64,
    pub token_total_supply: u64,
    pub fee_basis_points: u64,
}

#[derive(BorshDeserialize, BorshSerialize, Debug, Clone)]
pub struct BondingCurve {
    pub virtual_token_reserves: u64,
    pub virtual_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub token_total_supply: u64,
    pub complete: bool,
}

impl BondingCurve {
    /// Calculate SOL output for given token input (sell)
    pub fn calculate_sell_output(&self, token_amount: u64) -> Option<u64> {
        if token_amount == 0 || token_amount > self.virtual_token_reserves {
            return None;
        }
        // Constant product: (v_token - t) * (v_sol + s) = v_token * v_sol
        // s = (v_token * v_sol) / (v_token - t) - v_sol
        let v_token = self.virtual_token_reserves as u128;
        let v_sol = self.virtual_sol_reserves as u128;
        let t = token_amount as u128;
        
        let new_v_token = v_token.checked_sub(t)?;
        let product = v_token.checked_mul(v_sol)?;
        let new_v_sol = product.checked_div(new_v_token)?;
        let sol_out = new_v_sol.checked_sub(v_sol)?;
        
        Some(sol_out as u64)
    }

    /// Calculate token output for given SOL input (buy)
    pub fn calculate_buy_output(&self, sol_amount: u64) -> Option<u64> {
        if sol_amount == 0 {
            return None;
        }
        // Constant product: (v_token - t) * (v_sol + s) = v_token * v_sol
        // t = v_token - (v_token * v_sol) / (v_sol + s)
        let v_token = self.virtual_token_reserves as u128;
        let v_sol = self.virtual_sol_reserves as u128;
        let s = sol_amount as u128;
        
        let new_v_sol = v_sol.checked_add(s)?;
        let product = v_token.checked_mul(v_sol)?;
        let new_v_token = product.checked_div(new_v_sol)?;
        let token_out = v_token.checked_sub(new_v_token)?;
        
        Some(token_out as u64)
    }

    /// Calculate price impact percentage for a buy
    pub fn price_impact_buy(&self, sol_amount: u64) -> Option<f64> {
        let token_out = self.calculate_buy_output(sol_amount)?;
        if token_out == 0 {
            return None;
        }
        // Current price: virtual_sol / virtual_token
        let current_price = self.virtual_sol_reserves as f64 / self.virtual_token_reserves as f64;
        // Effective price: sol_amount / token_out
        let effective_price = sol_amount as f64 / token_out as f64;
        // Impact = (effective - current) / current * 100
        Some((effective_price - current_price) / current_price * 100.0)
    }

    /// Get current token price in SOL
    pub fn current_price_sol_per_token(&self) -> f64 {
        self.virtual_sol_reserves as f64 / self.virtual_token_reserves as f64
    }
}

/// Parse instruction data from transaction
pub fn parse_pump_instruction(data: &[u8]) -> Option<PumpInstruction> {
    if data.len() < 8 {
        return None;
    }
    let discriminator: [u8; 8] = data[0..8].try_into().ok()?;
    let payload = &data[8..];
    
    match discriminator {
        BUY_DISCRIMINATOR => {
            BuyInstructionData::try_from_slice(payload).ok()
                .map(PumpInstruction::Buy)
        }
        SELL_DISCRIMINATOR => {
            SellInstructionData::try_from_slice(payload).ok()
                .map(PumpInstruction::Sell)
        }
        CREATE_DISCRIMINATOR => {
            CreateInstructionData::try_from_slice(payload).ok()
                .map(PumpInstruction::Create)
        }
        _ => None,
    }
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub enum PumpInstruction {
    Buy(BuyInstructionData),
    Sell(SellInstructionData),
    Create(CreateInstructionData),
}

impl PumpInstruction {
    pub fn is_buy(&self) -> bool {
        matches!(self, PumpInstruction::Buy(_))
    }
    
    pub fn is_sell(&self) -> bool {
        matches!(self, PumpInstruction::Sell(_))
    }
    
    pub fn buy_amount(&self) -> Option<u64> {
        match self {
            PumpInstruction::Buy(data) => Some(data.amount),
            _ => None,
        }
    }
    
    pub fn sell_amount(&self) -> Option<u64> {
        match self {
            PumpInstruction::Sell(data) => Some(data.amount),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_bonding_curve_math() {
        // Typical initial state: 1.07B tokens, 30 SOL virtual
        let curve = BondingCurve {
            virtual_token_reserves: 1_073_000_000_000_000,
            virtual_sol_reserves: 30_000_000_000,
            real_token_reserves: 793_100_000_000_000,
            real_sol_reserves: 0,
            token_total_supply: 1_000_000_000_000_000,
            complete: false,
        };
        
        // Buy 1 SOL worth
        let tokens = curve.calculate_buy_output(1_000_000_000).unwrap();
        assert!(tokens > 0);
        
        // Sell those tokens back
        let sol_back = curve.calculate_sell_output(tokens).unwrap();
        assert!(sol_back < 1_000_000_000); // Loss due to curve
        
        // Price impact should be positive
        let impact = curve.price_impact_buy(1_000_000_000).unwrap();
        assert!(impact > 0.0);
    }
}