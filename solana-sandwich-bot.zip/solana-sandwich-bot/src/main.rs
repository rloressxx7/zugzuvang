use anyhow::{Context, Result};
use clap::Parser;
use dashmap::DashMap;
use solana_sdk::{
    commitment_config::CommitmentConfig,
    hash::Hash,
    signature::{Keypair, Signer},
    system_instruction,
};
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio::time::{Duration, Instant};
use tracing::{info, warn, error};

mod pump_idl;
mod mempool_monitor;
mod transaction_builder;
mod jito_bundler;
mod utils;
mod types;
mod flash_loan;
mod rpc_client;

use crate::mempool_monitor::MempoolMonitor;
use crate::transaction_builder::{
    create_pump_buy_ix, create_pump_sell_ix, find_bonding_curve, find_associated_bonding_curve,
};
use crate::jito_bundler::JitoBundler;
use crate::utils::{load_keypair, load_config, init_logging, format_sol, format_sol_signed, RateLimiter, CircuitBreaker, PnLTracker, ensure_dir};
use crate::types::{Config, CandidateTx, PumpCurveState, Position, PositionStatus, BundleResult, SimulationResult, JitoBundleConfig};
use crate::rpc_client::RpcClient;

#[derive(Parser, Debug)]
#[command(name = "sandwich-bot")]
#[command(about = "Pump.fun MEV Sandwich Bot", long_about = None)]
struct Args {
    #[arg(short, long, default_value = "config.toml")]
    config: String,

    #[arg(short, long)]
    dry_run: bool,

    #[arg(long)]
    test_mode: bool,
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();

    // Load config
    let config = load_config(&args.config).context("Failed to load config")?;

    // Initialize logging
    ensure_dir(&config.logging.log_file).context("Failed to create log dir")?;
    init_logging(&config.logging.level, Some(&config.logging.log_file))
        .context("Failed to initialize logging")?;

    info!("Starting Pump.fun MEV Sandwich Bot");
    info!("Dry run: {}", args.dry_run);
    info!("Test mode: {}", args.test_mode);

    // Load wallet
    let wallet = load_keypair(&config.wallet.keypair_path)
        .context("Failed to load wallet keypair")?;
    info!("Wallet loaded: {}", wallet.pubkey());

    // Load Jito auth keypair
    let mut jito_bundler = JitoBundler::new(JitoBundleConfig {
        block_engine_url: config.jito.block_engine_url.clone(),
        tip_accounts: config.jito.tip_accounts.clone(),
    })?;

    jito_bundler.load_auth_keypair(&config.jito.auth_keypair_path)
        .context("Failed to load Jito auth keypair")?;
    info!("Jito auth loaded");

    // RPC client (custom, no solana-client dep)
    let rpc_client = Arc::new(RpcClient::new_with_commitment(
        config.network.rpc_http.clone(),
        CommitmentConfig::processed(),
    ));

    // Test RPC connection
    let slot = rpc_client.get_slot().await.context("RPC connection failed")?;
    info!("RPC connected, current slot: {}", slot);

    // Get recent blockhash
    let recent_blockhash = rpc_client.get_latest_blockhash().await
        .context("Failed to get recent blockhash")?;

    // Shared state
    let curve_cache = Arc::new(DashMap::<solana_sdk::pubkey::Pubkey, PumpCurveState>::new());
    let positions = Arc::new(DashMap::<solana_sdk::pubkey::Pubkey, Position>::new());
    let pnl_tracker = Arc::new(PnLTracker::new());
    let rate_limiter = Arc::new(RateLimiter::new(config.risk.max_rpc_errors_per_minute));
    let circuit_breaker = Arc::new(CircuitBreaker::new(10, 60));

    // Channel for candidates
    let (candidate_tx, mut candidate_rx) = mpsc::channel::<CandidateTx>(1000);

    // Start mempool monitor
    let monitor = MempoolMonitor::new(
        config.network.rpc_ws.clone(),
        rpc_client.clone(),
        candidate_tx,
        curve_cache.clone(),
        config.strategy.target_min_buy_sol,
    );

    let monitor_handle = tokio::spawn(async move {
        if let Err(e) = monitor.run().await {
            error!("Mempool monitor error: {}", e);
        }
    });

    // Main processing loop
    let config = Arc::new(config);
    let wallet = Arc::new(wallet);
    let rpc_client = Arc::new(rpc_client);
    let jito_bundler = Arc::new(jito_bundler);

    info!("Entering main processing loop");

    while let Some(candidate) = candidate_rx.recv().await {
        // Check circuit breaker
        if circuit_breaker.is_open() {
            warn!("Circuit breaker open, skipping candidate");
            continue;
        }

        // Check daily loss limit
        let max_daily_loss = (config.strategy.max_daily_loss_sol * 1e9) as u64;
        if pnl_tracker.daily_loss_exceeded(max_daily_loss) {
            error!("Daily loss limit exceeded, stopping");
            break;
        }

        // Check concurrent positions
        if positions.len() >= config.strategy.max_concurrent_positions as usize {
            warn!("Max concurrent positions reached, skipping");
            continue;
        }

        // Process candidate
        let config = config.clone();
        let wallet = wallet.clone();
        let rpc_client = rpc_client.clone();
        let jito_bundler = jito_bundler.clone();
        let curve_cache = curve_cache.clone();
        let positions = positions.clone();
        let pnl_tracker = pnl_tracker.clone();
        let circuit_breaker = circuit_breaker.clone();
        let rate_limiter = rate_limiter.clone();

        tokio::spawn(async move {
            if let Err(e) = process_candidate(
                candidate,
                config,
                wallet,
                rpc_client,
                jito_bundler,
                curve_cache,
                positions,
                pnl_tracker,
                circuit_breaker,
                rate_limiter,
                args.dry_run,
            ).await {
                error!("Candidate processing error: {}", e);
            }
        });
    }

    monitor_handle.await?;
    Ok(())
}

async fn process_candidate(
    mut candidate: CandidateTx,
    config: Arc<Config>,
    wallet: Arc<Keypair>,
    rpc_client: Arc<RpcClient>,
    jito_bundler: Arc<JitoBundler>,
    curve_cache: Arc<DashMap<solana_sdk::pubkey::Pubkey, PumpCurveState>>,
    positions: Arc<DashMap<solana_sdk::pubkey::Pubkey, Position>>,
    pnl_tracker: Arc<PnLTracker>,
    circuit_breaker: Arc<CircuitBreaker>,
    rate_limiter: Arc<RateLimiter>,
    dry_run: bool,
) -> Result<()> {
    let start = Instant::now();

    info!("Processing candidate: curve={}, buy_amount={} SOL",
        candidate.curve_address, format_sol(candidate.buy_amount_lamports));

    // Get mint from curve address (reverse lookup would need getProgramAccounts)
    // For now, derive from candidate instruction if available
    let mint = match &candidate.instruction {
        crate::pump_idl::PumpInstruction::Buy(_) => {
            // We'd need to fetch transaction to get mint
            // Placeholder: derive from curve PDA
            candidate.curve_address // This is wrong, need actual mint
        }
        _ => return Ok(()),
    };

    // Fetch curve state if not cached
    let curve_state = if let Some(cached) = curve_cache.get(&candidate.curve_address) {
        if cached.last_updated > std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs() - 60
        {
            cached.clone()
        } else {
            fetch_curve_state(&rpc_client, &candidate.curve_address, &mint).await?
        }
    } else {
        fetch_curve_state(&rpc_client, &candidate.curve_address, &mint).await?
    };

    curve_cache.insert(candidate.curve_address, curve_state.clone());

    // Calculate front-run amount (slightly less than target buy to front-run)
    let front_run_sol = (candidate.buy_amount_lamports as f64 * 0.95) as u64;
    let front_run_max_sol = (front_run_sol as f64 * 1.02) as u64; // 2% slippage buffer

    // Calculate expected tokens from front-run
    let tokens_bought = curve_state.calculate_buy_output(front_run_sol)
        .ok_or_else(|| anyhow::anyhow!("Failed to calculate buy output"))?;

    // Calculate back-run (sell all tokens with slippage)
    let back_run_min_sol = curve_state.calculate_sell_output(tokens_bought)
        .ok_or_else(|| anyhow::anyhow!("Failed to calculate sell output"))?;
    let back_run_min_sol = (back_run_min_sol as f64 * (1.0 - config.strategy.backrun_slippage_bps as f64 / 10000.0)) as u64;

    // Simulate if enabled
    if config.risk.simulate_before_submit {
        let sim = simulate_bundle(
            &rpc_client,
            &wallet.pubkey(),
            &mint,
            &candidate.curve_address,
            front_run_sol,
            front_run_max_sol,
            tokens_bought,
            back_run_min_sol,
        ).await?;

        if !sim.success {
            warn!("Simulation failed: {:?}", sim.error);
            circuit_breaker.record_error();
            return Ok(());
        }

        if sim.estimated_profit < config.strategy.min_profit_lamports as i64 {
            info!("Profit below threshold: {} < {}", format_sol_signed(sim.estimated_profit), format_sol(config.strategy.min_profit_lamports));
            return Ok(());
        }

        if sim.price_impact_pct > config.risk.max_price_impact_pct {
            warn!("Price impact too high: {:.2}%", sim.price_impact_pct);
            return Ok(());
        }

        info!("Simulation OK: profit={}, impact={:.2}%", format_sol_signed(sim.estimated_profit), sim.price_impact_pct);
    }

    // Build transactions
    let associated_bonding_curve = find_associated_bonding_curve(&mint, &candidate.curve_address);

    let (front_run_ix, back_run_ix) = crate::transaction_builder::build_sandwich_tx(
        &wallet.pubkey(),
        &mint,
        &candidate.curve_address,
        &associated_bonding_curve,
        front_run_sol,
        front_run_max_sol,
        tokens_bought,
        back_run_min_sol,
    )?;

    // Get recent blockhash
    rate_limiter.wait().await;
    let recent_blockhash = rpc_client.get_latest_blockhash().await?;

    // Create transactions
    let front_run_tx = jito_bundler.create_transaction(vec![front_run_ix], recent_blockhash, &wallet);
    let back_run_tx = jito_bundler.create_transaction(vec![back_run_ix], recent_blockhash, &wallet);

    // Add tip transaction (Jito requirement)
    let tip_ix = system_instruction::transfer(
        &wallet.pubkey(),
        &config.jito.tip_accounts[0].parse().unwrap(),
        config.strategy.front_run_tip_lamports,
    );
    let tip_tx = jito_bundler.create_transaction(vec![tip_ix], recent_blockhash, &wallet);

    // Submit bundle
    if !dry_run {
        let bundle_id = jito_bundler.submit_bundle(&[front_run_tx, back_run_tx, tip_tx]).await?;
        info!("Bundle submitted: {}", bundle_id);

        // Wait for confirmation
        match jito_bundler.wait_for_confirmation(&bundle_id, 30).await {
            Ok(status) => {
                info!("Bundle landed: {:?}", status);

                // Calculate actual profit
                // This would need to fetch transaction results
                let profit = 0i64; // Placeholder
                pnl_tracker.record_trade(profit);
                circuit_breaker.record_success();
            }
            Err(e) => {
                error!("Bundle failed: {}", e);
                pnl_tracker.record_trade(-(config.strategy.front_run_tip_lamports as i64));
                circuit_breaker.record_error();
            }
        }
    } else {
        info!("DRY RUN: Would submit bundle with front_run={}, back_run={}, tip={}",
            format_sol(front_run_sol), format_sol(tokens_bought), format_sol(config.strategy.front_run_tip_lamports));
    }

    let elapsed = start.elapsed();
    info!("Candidate processed in {:?}", elapsed);

    Ok(())
}

async fn fetch_curve_state(
    rpc_client: &RpcClient,
    curve_address: &solana_sdk::pubkey::Pubkey,
    mint: &solana_sdk::pubkey::Pubkey,
) -> Result<PumpCurveState> {
    // Fetch bonding curve account data
    let account = rpc_client.get_account(curve_address).await
        .context("Failed to fetch bonding curve account")?;

    // Parse bonding curve data (simplified - real parsing uses Borsh)
    // For now, return default state
    Ok(PumpCurveState {
        curve_address: *curve_address,
        mint: *mint,
        virtual_token_reserves: 1_073_000_000_000_000,
        virtual_sol_reserves: 30_000_000_000,
        real_token_reserves: 793_100_000_000_000,
        real_sol_reserves: 0,
        token_total_supply: 1_000_000_000_000_000,
        complete: false,
        last_updated: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs(),
    })
}

async fn simulate_bundle(
    rpc_client: &RpcClient,
    wallet: &solana_sdk::pubkey::Pubkey,
    mint: &solana_sdk::pubkey::Pubkey,
    curve_address: &solana_sdk::pubkey::Pubkey,
    front_run_sol: u64,
    front_run_max_sol: u64,
    tokens_bought: u64,
    back_run_min_sol: u64,
) -> Result<SimulationResult> {
    // Build transactions for simulation
    let associated_bonding_curve = find_associated_bonding_curve(mint, curve_address);

    let (front_run_ix, back_run_ix) = crate::transaction_builder::build_sandwich_tx(
        wallet,
        mint,
        curve_address,
        &associated_bonding_curve,
        front_run_sol,
        front_run_max_sol,
        tokens_bought,
        back_run_min_sol,
    )?;

    let _recent_blockhash = rpc_client.get_latest_blockhash().await?;

    // Use simulateTransaction RPC
    // Simplified: return estimated result
    Ok(SimulationResult {
        success: true,
        front_run_sol_out: front_run_sol,
        back_run_sol_in: back_run_min_sol,
        estimated_profit: back_run_min_sol as i64 - front_run_sol as i64,
        price_impact_pct: 1.0,
        units_consumed: 200_000,
        error: None,
    })
}