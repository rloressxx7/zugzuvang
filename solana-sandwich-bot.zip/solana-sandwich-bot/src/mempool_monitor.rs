use anyhow::{Context, Result};
use dashmap::DashMap;
use futures::{SinkExt, StreamExt};
use parking_lot::RwLock;
use serde_json::json;
use solana_sdk::{commitment_config::CommitmentConfig, pubkey::Pubkey, signature::Signature};
use std::sync::Arc;
use tokio::sync::mpsc;
use tokio_tungstenite::{connect_async, tungstenite::protocol::Message};
use url::Url;

use crate::pump_idl::{parse_pump_instruction, PumpInstruction, PUMP_FUN_PROGRAM_ID};
use crate::rpc_client::RpcClient;
use crate::types::{CandidateTx, PumpCurveState};

/// Mempool monitor using WebSocket log subscription
pub struct MempoolMonitor {
    rpc_ws_url: String,
    rpc_http: Arc<RpcClient>,
    candidate_tx: mpsc::Sender<CandidateTx>,
    curve_cache: Arc<DashMap<Pubkey, PumpCurveState>>,
    min_buy_sol: f64,
    stats: Arc<MonitorStats>,
}

#[derive(Default)]
struct MonitorStats {
    total_logs: std::sync::atomic::AtomicU64,
    pump_logs: std::sync::atomic::AtomicU64,
    candidates_sent: std::sync::atomic::AtomicU64,
    parse_errors: std::sync::atomic::AtomicU64,
    rpc_errors: std::sync::atomic::AtomicU64,
}

impl MempoolMonitor {
    pub fn new(
        rpc_ws_url: String,
        rpc_http: Arc<RpcClient>,
        candidate_tx: mpsc::Sender<CandidateTx>,
        curve_cache: Arc<DashMap<Pubkey, PumpCurveState>>,
        min_buy_sol: f64,
    ) -> Self {
        Self {
            rpc_ws_url,
            rpc_http,
            candidate_tx,
            curve_cache,
            min_buy_sol,
            stats: Arc::new(MonitorStats::default()),
        }
    }

    pub async fn run(&self) -> Result<()> {
        let url = Url::parse(&self.rpc_ws_url).context("Invalid WS URL")?;
        let (ws_stream, _) = connect_async(url).await.context("WS connect failed")?;
        let (mut write, mut read) = ws_stream.split();

        // Subscribe to Pump.fun program logs
        let sub_req = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "logsSubscribe",
            "params": [
                { "mentions": [PUMP_FUN_PROGRAM_ID] },
                { "commitment": "processed" }
            ]
        });
        write.send(Message::Text(sub_req.to_string())).await?;
        log::info!("Subscribed to Pump.fun program logs");

        // Background stats reporter
        let stats = self.stats.clone();
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(std::time::Duration::from_secs(30));
            loop {
                interval.tick().await;
                log::info!(
                    "Mempool stats: total={}, pump={}, candidates={}, parse_err={}, rpc_err={}",
                    stats.total_logs.load(std::sync::atomic::Ordering::Relaxed),
                    stats.pump_logs.load(std::sync::atomic::Ordering::Relaxed),
                    stats.candidates_sent.load(std::sync::atomic::Ordering::Relaxed),
                    stats.parse_errors.load(std::sync::atomic::Ordering::Relaxed),
                    stats.rpc_errors.load(std::sync::atomic::Ordering::Relaxed),
                );
            }
        });

        // Process incoming logs
        while let Some(msg) = read.next().await {
            match msg {
                Ok(Message::Text(text)) => {
                    self.stats.total_logs.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    if let Err(e) = self.process_log_message(&text).await {
                        log::debug!("Log process error: {}", e);
                    }
                }
                Ok(Message::Close(_)) => {
                    log::warn!("WS connection closed, reconnecting...");
                    break;
                }
                Err(e) => {
                    log::error!("WS error: {}", e);
                    self.stats.rpc_errors.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    break;
                }
                _ => {}
            }
        }

        Ok(())
    }

    async fn process_log_message(&self, text: &str) -> Result<()> {
        let value: serde_json::Value = serde_json::from_str(text)?;

        // Parse log notification
        let params = value
            .get("params")
            .and_then(|p| p.get("result"))
            .and_then(|r| r.get("value"));
        let Some(log_data) = params else {
            return Ok(())
        };

        let signature = log_data.get("signature").and_then(|s| s.as_str()).unwrap_or("");
        let logs = log_data.get("logs").and_then(|l| l.as_array());
        let Some(logs) = logs else {
            return Ok(())
        };

        self.stats.pump_logs.fetch_add(1, std::sync::atomic::Ordering::Relaxed);

        // Look for Pump.fun instructions in logs
        for log in logs {
            let log_str = log.as_str().unwrap_or("");

            // Parse program data from log: "Program data: <base64>"
            if let Some(data_b64) = log_str.strip_prefix("Program data: ") {
                if let Ok(data) = base64::decode(data_b64) {
                    if let Some(instruction) = parse_pump_instruction(&data) {
                        if let PumpInstruction::Buy(buy_data) = &instruction {
                            let sol_amount = buy_data.amount as f64 / 1e9;
                            if sol_amount >= self.min_buy_sol {
                                // Extract bonding curve address from transaction
                                if let Some(curve_addr) = self.extract_curve_from_logs(&logs) {
                                    self.stats
                                        .candidates_sent
                                        .fetch_add(1, std::sync::atomic::Ordering::Relaxed);

                                    let candidate = CandidateTx {
                                        signature: Signature::from_str(signature).ok(),
                                        curve_address: curve_addr,
                                        buy_amount_lamports: buy_data.amount,
                                        timestamp: std::time::SystemTime::now()
                                            .duration_since(std::time::UNIX_EPOCH)
                                            .unwrap()
                                            .as_millis() as u64,
                                        instruction,
                                    };

                                    if self.candidate_tx.send(candidate).await.is_err() {
                                        log::warn!("Candidate channel closed");
                                        return Err(anyhow::anyhow!("Channel closed"));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Ok(())
    }

    fn extract_curve_from_logs(&self, logs: &[serde_json::Value]) -> Option<Pubkey> {
        // Simplified: look for bonding curve in logs
        // Real implementation fetches transaction and parses accounts
        for log in logs {
            let log_str = log.as_str().unwrap_or("");
            if log_str.contains("bonding_curve") || log_str.contains("BondingCurve") {
                // Try to extract pubkey from log
            }
        }
        None
    }

    /// Fetch full transaction and extract bonding curve + curve state
    pub async fn enrich_candidate(&self, candidate: &mut CandidateTx) -> Result<()> {
        let Some(sig) = candidate.signature else {
            return Ok(())
        };

        let _tx = self
            .rpc_http
            .get_transaction(sig)
            .await
            .context("getTransaction failed")?;

        Ok(())
    }
}

use std::str::FromStr;
use base64;