use anyhow::Result;
use solana_program::instruction::{AccountMeta, Instruction};
use solana_sdk::{pubkey::Pubkey, system_program, sysvar};

use crate::token::token_program_id;

/// Solend program ID (main pool).
pub const SOLEND_PROGRAM_ID: &str = "So1endDq2YkqhipRh3WViPa8hdiSpxWy6z3Z6tMCpAo";

/// Placeholder Solend flash loan discriminator — real value comes from
/// the Solend IDL; this exists so the module compiles and is testable in
/// isolation.
pub const FLASH_LOAN_DISCRIMINATOR: [u8; 8] = [0x0e, 0x2b, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06];

/// Create the flash-loan borrow instruction.
///
/// NOTE: This is a template. A real Solend flash-loan requires:
/// 1. Reserve accounts (liquidity supply, liquidity borrow, collateral, etc.)
/// 2. Market authority and market account
/// 3. A receiver program implementing Solend's flash-loan callback CPI
/// 4. The exact 8-byte discriminator from the Solend IDL
pub fn create_flash_loan_ix(
    lender: &Pubkey,
    receiver: &Pubkey,
    reserve: &Pubkey,
    amount: u64,
    callback_accounts: Vec<AccountMeta>,
) -> Result<Instruction> {
    let program_id: Pubkey = SOLEND_PROGRAM_ID.parse().unwrap();

    let mut data = Vec::with_capacity(8 + 8 + 32 + 32);
    data.extend_from_slice(&FLASH_LOAN_DISCRIMINATOR);
    data.extend_from_slice(&amount.to_le_bytes());
    data.extend_from_slice(receiver.as_ref());
    data.extend_from_slice(reserve.as_ref());

    let mut accounts = vec![
        AccountMeta::new(*reserve, false),
        AccountMeta::new(*receiver, false),
        AccountMeta::new_readonly(*lender, false),
        AccountMeta::new_readonly(sysvar::clock::id(), false),
        AccountMeta::new_readonly(token_program_id(), false),
    ];
    accounts.extend(callback_accounts);

    Ok(Instruction {
        program_id,
        accounts,
        data,
    })
}

/// Build a 3-instruction sandwich using a flash loan. Caller is expected
/// to wrap these in a single transaction (atomicity on Solana is per-tx,
/// not per-bundle).
pub fn create_flash_loan_sandwich_ix(
    wallet: &Pubkey,
    mint: &Pubkey,
    bonding_curve: &Pubkey,
    associated_bonding_curve: &Pubkey,
    solend_reserve: &Pubkey,
    flash_loan_amount: u64,
    front_run_amount: u64,
    front_run_max_sol: u64,
    back_run_tokens: u64,
    back_run_min_sol: u64,
    repayment_amount: u64,
) -> Result<(Instruction, Instruction, Instruction)> {
    // 1. Flash-loan borrow
    let flash_loan_ix = create_flash_loan_ix(
        &SOLEND_PROGRAM_ID.parse().unwrap(),
        wallet,
        solend_reserve,
        flash_loan_amount,
        vec![],
    )?;

    // 2. Front-run buy with flash-loan funds
    let front_run_ix = crate::transaction_builder::create_pump_buy_ix(
        wallet,
        mint,
        bonding_curve,
        associated_bonding_curve,
        front_run_amount,
        front_run_max_sol,
    )?;

    // 3. Repay flash loan (placeholder discriminator)
    let repay_ix = create_repay_flash_loan_ix(wallet, solend_reserve, repayment_amount)?;

    Ok((flash_loan_ix, front_run_ix, repay_ix))
}

/// Placeholder repayment instruction.
fn create_repay_flash_loan_ix(
    wallet: &Pubkey,
    reserve: &Pubkey,
    amount: u64,
) -> Result<Instruction> {
    let program_id: Pubkey = SOLEND_PROGRAM_ID.parse().unwrap();

    let mut data = Vec::with_capacity(8 + 8);
    data.extend_from_slice(&[0x0d; 8]); // TODO: real repay discriminator
    data.extend_from_slice(&amount.to_le_bytes());

    let accounts = vec![
        AccountMeta::new(*wallet, true),
        AccountMeta::new(*reserve, false),
        AccountMeta::new_readonly(token_program_id(), false),
        AccountMeta::new_readonly(system_program::id(), false),
    ];

    Ok(Instruction {
        program_id,
        accounts,
        data,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_flash_loan_discriminator() {
        assert_eq!(FLASH_LOAN_DISCRIMINATOR[0], 0x0e);
    }
}
