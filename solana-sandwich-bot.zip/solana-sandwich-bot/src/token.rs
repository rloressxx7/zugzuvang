//! Inline SPL Token constants and ATA derivation — avoids pulling in
//! `spl-token` / `spl-associated-token-account` crates which transitively
//! depend on conflicting solana-program versions.

use solana_sdk::pubkey::Pubkey;

/// SPL Token program ID
pub const TOKEN_PROGRAM_ID_STR: &str = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";

/// SPL Associated Token Account program ID
pub const ASSOCIATED_TOKEN_PROGRAM_ID_STR: &str = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";

/// Parsed Pubkey for the SPL Token program.
pub fn token_program_id() -> Pubkey {
    TOKEN_PROGRAM_ID_STR.parse().expect("valid token program id")
}

/// Parsed Pubkey for the Associated Token Account program.
pub fn associated_token_program_id() -> Pubkey {
    ASSOCIATED_TOKEN_PROGRAM_ID_STR
        .parse()
        .expect("valid ATA program id")
}

/// Derive the Associated Token Account address for (wallet, mint).
///
/// ATA = PDA(seeds = [wallet, TOKEN_PROGRAM_ID, mint], program = ATA_PROGRAM_ID)
pub fn get_associated_token_address(wallet: &Pubkey, mint: &Pubkey) -> Pubkey {
    let token_id = token_program_id();
    let ata_program = associated_token_program_id();
    let (addr, _bump) = Pubkey::find_program_address(
        &[wallet.as_ref(), token_id.as_ref(), mint.as_ref()],
        &ata_program,
    );
    addr
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn known_ata_derivation_works() {
        let wallet: Pubkey = "BPFLoaderUpgradeab1e11111111111111111111111"
            .parse()
            .unwrap();
        let mint: Pubkey = "So11111111111111111111111111111111111111112"
            .parse()
            .unwrap();
        let ata = get_associated_token_address(&wallet, &mint);
        assert_ne!(ata, Pubkey::default());
        assert_ne!(ata, wallet);
        assert_ne!(ata, mint);
    }
}
