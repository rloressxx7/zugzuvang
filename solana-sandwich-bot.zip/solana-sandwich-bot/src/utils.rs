use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use solana_sdk::{pubkey::Pubkey, signature::Keypair};
use std::fs;
use std::path::Path;
use std::time::{Duration, Instant};

use crate::types::Config;

fn expand_path(path: &str) -> String {
    if path.starts_with("~/") {
        let home = std::env::var("USERPROFILE").unwrap_or_else(|_| "C:/Users/Default".to_string());
        path.replace("~", &home)
    } else {
        path.to_string()
    }
}

/// Load wallet keypair from file
pub fn load_keypair(path: &str) -> Result<Keypair> {
    let path = expand_path(path);
    let content = fs::read_to_string(&path)
        .with_context(|| format!("Failed to read keypair from {}", path))?;
    
    let bytes: Vec<u8> = serde_json::from_str(&content)
        .with_context(|| "Invalid keypair JSON format (expected array of u8)")?;
    
    if bytes.len() != 64 {
        return Err(anyhow::anyhow!("Keypair must be 64 bytes, got {}", bytes.len()));
    }
    
    Keypair::from_bytes(&bytes)
        .with_context(|| "Invalid keypair bytes")
}

/// Load config from TOML file
pub fn load_config(path: &str) -> Result<Config> {
    let path = expand_path(path);
    let content = fs::read_to_string(&path)
        .with_context(|| format!("Failed to read config from {}", path))?;
    
    toml::from_str(&content)
        .with_context(|| "Failed to parse config TOML")
}

/// Ensure directory exists
pub fn ensure_dir(path: &str) -> Result<()> {
    let path = Path::new(path);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)
            .with_context(|| format!("Failed to create directory {}", parent.display()))?;
    }
    Ok(())
}

/// Rate limiter for RPC calls
pub struct RateLimiter {
    max_per_minute: u32,
    calls: parking_lot::Mutex<Vec<Instant>>,
}

impl RateLimiter {
    pub fn new(max_per_minute: u32) -> Self {
        Self {
            max_per_minute,
            calls: parking_lot::Mutex::new(Vec::new()),
        }
    }

    pub fn check(&self) -> bool {
        let mut calls = self.calls.lock();
        let now = Instant::now();
        let minute_ago = now - Duration::from_secs(60);
        
        // Remove old calls
        calls.retain(|&t| t > minute_ago);
        
        if calls.len() >= self.max_per_minute as usize {
            false
        } else {
            calls.push(now);
            true
        }
    }

    pub async fn wait(&self) {
        while !self.check() {
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
    }
}

/// Circuit breaker for error handling
pub struct CircuitBreaker {
    max_errors: u32,
    window_secs: u64,
    errors: parking_lot::Mutex<Vec<Instant>>,
    open: parking_lot::Mutex<bool>,
}

impl CircuitBreaker {
    pub fn new(max_errors: u32, window_secs: u64) -> Self {
        Self {
            max_errors,
            window_secs,
            errors: parking_lot::Mutex::new(Vec::new()),
            open: parking_lot::Mutex::new(false),
        }
    }

    pub fn record_error(&self) {
        let mut errors = self.errors.lock();
        let now = Instant::now();
        let window_ago = now - Duration::from_secs(self.window_secs);
        
        errors.retain(|&t| t > window_ago);
        errors.push(now);
        
        if errors.len() >= self.max_errors as usize {
            *self.open.lock() = true;
            log::error!("Circuit breaker OPENED - too many errors");
        }
    }

    pub fn record_success(&self) {
        let mut errors = self.errors.lock();
        let now = Instant::now();
        let window_ago = now - Duration::from_secs(self.window_secs);
        errors.retain(|&t| t > window_ago);
        
        if errors.is_empty() {
            *self.open.lock() = false;
        }
    }

    pub fn is_open(&self) -> bool {
        *self.open.lock()
    }
}

/// PnL tracker
#[derive(Default)]
pub struct PnLTracker {
    total_profit: parking_lot::Mutex<i64>, // lamports
    total_trades: parking_lot::Mutex<u64>,
    winning_trades: parking_lot::Mutex<u64>,
    daily_loss: parking_lot::Mutex<i64>,
    last_reset: parking_lot::Mutex<Instant>,
}

impl PnLTracker {
    pub fn new() -> Self {
        Self {
            last_reset: parking_lot::Mutex::new(Instant::now()),
            ..Default::default()
        }
    }

    pub fn record_trade(&self, profit_lamports: i64) {
        let mut total = self.total_profit.lock();
        *total += profit_lamports;
        
        let mut trades = self.total_trades.lock();
        *trades += 1;
        
        if profit_lamports > 0 {
            let mut wins = self.winning_trades.lock();
            *wins += 1;
        } else {
            let mut loss = self.daily_loss.lock();
            *loss += profit_lamports; // negative
        }
        
        self.check_daily_reset();
    }

    fn check_daily_reset(&self) {
        let mut last = self.last_reset.lock();
        if last.elapsed() > Duration::from_secs(86400) {
            *self.daily_loss.lock() = 0;
            *last = Instant::now();
        }
    }

    pub fn get_stats(&self) -> PnLStats {
        PnLStats {
            total_profit_lamports: *self.total_profit.lock(),
            total_trades: *self.total_trades.lock(),
            winning_trades: *self.winning_trades.lock(),
            daily_loss_lamports: *self.daily_loss.lock(),
        }
    }

    pub fn daily_loss_exceeded(&self, max_loss_lamports: u64) -> bool {
        -*self.daily_loss.lock() > max_loss_lamports as i64
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PnLStats {
    pub total_profit_lamports: i64,
    pub total_trades: u64,
    pub winning_trades: u64,
    pub daily_loss_lamports: i64,
}

impl PnLStats {
    pub fn win_rate(&self) -> f64 {
        if self.total_trades == 0 { 0.0 } else { self.winning_trades as f64 / self.total_trades as f64 }
    }
    
    pub fn total_profit_sol(&self) -> f64 {
        self.total_profit_lamports as f64 / 1e9
    }
}

/// Initialize logging
pub fn init_logging(level: &str, log_file: Option<&str>) -> Result<()> {
    let level = match level.to_lowercase().as_str() {
        "trace" => log::LevelFilter::Trace,
        "debug" => log::LevelFilter::Debug,
        "info" => log::LevelFilter::Info,
        "warn" => log::LevelFilter::Warn,
        "error" => log::LevelFilter::Error,
        _ => log::LevelFilter::Info,
    };
    
    let mut builder = env_logger::Builder::new();
    builder.filter_level(level);
    
    if let Some(file) = log_file {
        use std::io::Write;
        let file = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(file)
            .context("Failed to open log file")?;
        builder.target(env_logger::Target::Pipe(Box::new(file)));
    }
    
    builder.init();
    Ok(())
}

/// Format lamports as SOL string
pub fn format_sol(lamports: u64) -> String {
    format!("{:.6} SOL", lamports as f64 / 1e9)
}

/// Format signed lamports as SOL string
pub fn format_sol_signed(lamports: i64) -> String {
    format!("{:+.6} SOL", lamports as f64 / 1e9)
}