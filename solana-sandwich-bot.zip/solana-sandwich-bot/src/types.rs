use anyhow::Result;
use serde::{Deserialize, Serialize};
use solana_sdk::{pubkey::Pubkey, signature::{Keypair, Signature}};

/// Configuration loaded from config.toml
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Config {
    pub network: NetworkConfig,
    pub jito: JitoConfig,
    pub wallet: WalletConfig,
    pub strategy: StrategyConfig,
    pub risk: RiskConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct NetworkConfig {
    pub rpc_http: String,
    pub rpc_ws: String,
    // pub geyser_endpoint: Option<String>,
    // pub geyser_token: Option<String>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct JitoConfig {
    pub block_engine_url: String,
    pub auth_keypair_path: String,
    pub tip_accounts: Vec<String>,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct WalletConfig {
    pub keypair_path: String,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StrategyConfig {
    pub target_min_buy_sol: f64,
    pub max_position_sol: f64,
    pub max_daily_loss_sol: f64,
    pub max_concurrent_positions: u32,
    pub backrun_slippage_bps: u16,
    pub front_run_tip_lamports: u64,
    pub compute_unit_limit: u32,
    pub compute_unit_price_micro_lamports: u64,
    pub min_profit_lamports: u64,
    pub max_hold_seconds: u64,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct RiskConfig {
    pub simulate_before_submit: bool,
    pub max_sim_slippage_bps: u16,
    pub max_price_impact_pct: f64,
    pub max_rpc_errors_per_minute: u32,
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct LoggingConfig {
    pub level: String,
    pub log_file: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            network: NetworkConfig {
                rpc_http: "https://api.mainnet-beta.solana.com".to_string(),
                rpc_ws: "wss://api.mainnet-beta.solana.com".to_string(),
            },
            jito: JitoConfig {
                block_engine_url: "https://mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
                auth_keypair_path: "~/.config/solana/jito-auth.json".to_string(),
                tip_accounts: vec![
                    "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5".to_string(),
                    "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe".to_string(),
                ],
            },
            wallet: WalletConfig {
                keypair_path: "~/.config/solana/id.json".to_string(),
            },
            strategy: StrategyConfig {
                target_min_buy_sol: 50.0,
                max_position_sol: 100.0,
                max_daily_loss_sol: 10.0,
                max_concurrent_positions: 3,
                backrun_slippage_bps: 50,
                front_run_tip_lamports: 1_000_000,
                compute_unit_limit: 400_000,
                compute_unit_price_micro_lamports: 200_000,
                min_profit_lamports: 500_000,
                max_hold_seconds: 30,
            },
            risk: RiskConfig {
                simulate_before_submit: true,
                max_sim_slippage_bps: 100,
                max_price_impact_pct: 5.0,
                max_rpc_errors_per_minute: 10,
            },
            logging: LoggingConfig {
                level: "info".to_string(),
                log_file: "logs/sandwich-bot.log".to_string(),
            },
        }
    }
}

/// Jito bundle configuration
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct JitoBundleConfig {
    pub block_engine_url: String,
    pub tip_accounts: Vec<String>,
}

impl Default for JitoBundleConfig {
    fn default() -> Self {
        Self {
            block_engine_url: "https://mainnet.block-engine.jito.wtf/api/v1/bundles".to_string(),
            tip_accounts: vec![
                "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5".to_string(),
                "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe".to_string(),
            ],
        }
    }
}

use serde::{Deserialize, Serialize};
use solana_sdk::{pubkey::Pubkey, signature::Signature};

/// Candidate transaction from mempool
#[derive(Debug, Clone)]
pub struct CandidateTx {
    pub signature: Option<solana_sdk::signature::Signature>,
    pub curve_address: Pubkey,
    pub buy_amount_lamports: u64,
    pub timestamp: u64,
    pub instruction: crate::pump_idl::PumpInstruction,
}

/// Pump.fun bonding curve state (cached)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PumpCurveState {
    pub curve_address: Pubkey,
    pub mint: Pubkey,
    pub virtual_token_reserves: u64,
    pub virtual_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub token_total_supply: u64,
    pub complete: bool,
    pub last_updated: u64,
}

impl PumpCurveState {
    pub fn price_sol_per_token(&self) -> f64 {
        if self.virtual_token_reserves == 0 { 0.0 } else { self.virtual_sol_reserves as f64 / self.virtual_token_reserves as f64 }
    }
    
    pub fn calculate_buy_output(&self, sol_amount: u64) -> Option<u64> {
        if sol_amount == 0 { return None; }
        let v_token = self.virtual_token_reserves as u128;
        let v_sol = self.virtual_sol_reserves as u128;
        let s = sol_amount as u128;
        let new_v_sol = v_sol.checked_add(s)?;
        let product = v_token.checked_mul(v_sol)?;
        let new_v_token = product.checked_div(new_v_sol)?;
        let token_out = v_token.checked_sub(new_v_token)?;
        Some(token_out as u64)
    }
    
    pub fn calculate_sell_output(&self, token_amount: u64) -> Option<u64> {
        if token_amount == 0 || token_amount > self.virtual_token_reserves { return None; }
        let v_token = self.virtual_token_reserves as u128;
        let v_sol = self.virtual_sol_reserves as u128;
        let t = token_amount as u128;
        let new_v_token = v_token.checked_sub(t)?;
        let product = v_token.checked_mul(v_sol)?;
        let new_v_sol = product.checked_div(new_v_token)?;
        let sol_out = new_v_sol.checked_sub(v_sol)?;
        Some(sol_out as u64)
    }
    
    pub fn price_impact_buy(&self, sol_amount: u64) -> Option<f64> {
        let token_out = self.calculate_buy_output(sol_amount)?;
        if token_out == 0 { return None; }
        let current_price = self.virtual_sol_reserves as f64 / self.virtual_token_reserves as f64;
        let effective_price = sol_amount as f64 / token_out as f64;
        Some((effective_price - current_price) / current_price * 100.0)
    }
}

/// Active position tracking
#[derive(Debug, Clone)]
pub struct Position {
    pub mint: Pubkey,
    pub curve_address: Pubkey,
    pub entry_time: std::time::Instant,
    pub tokens_bought: u64,
    pub sol_spent: u64,
    pub front_run_sig: Option<solana_sdk::signature::Signature>,
    pub back_run_sig: Option<solana_sdk::signature::Signature>,
    pub status: PositionStatus,
}

#[derive(Debug, Clone, PartialEq)]
pub enum PositionStatus {
    PendingFrontRun,
    Holding,
    PendingBackRun,
    Closed,
    Failed(String),
}

/// Bundle submission result
#[derive(Debug, Clone)]
pub struct BundleResult {
    pub bundle_id: String,
    pub front_run_sig: solana_sdk::signature::Signature,
    pub back_run_sig: solana_sdk::signature::Signature,
    pub status: BundleStatus,
    pub profit_lamports: i64,
    pub confirmed_at: Option<u64>,
}

#[derive(Debug, Clone)]
pub enum BundleStatus {
    Submitted,
    Landed,
    Failed(String),
}

/// Simulation result
#[derive(Debug, Clone)]
pub struct SimulationResult {
    pub success: bool,
    pub front_run_sol_out: u64,
    pub back_run_sol_in: u64,
    pub estimated_profit: i64,
    pub price_impact_pct: f64,
    pub units_consumed: u64,
    pub error: Option<String>,
}