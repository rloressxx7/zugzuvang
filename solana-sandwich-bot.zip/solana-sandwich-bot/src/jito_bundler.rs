use anyhow::{Context, Result};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use solana_sdk::{
    hash::Hash,
    message::VersionedMessage,
    signature::{Keypair, Signature, Signer},
    transaction::VersionedTransaction,
};
use std::sync::Arc;
use tokio::time::{Duration, timeout};

use crate::types::JitoBundleConfig;

/// Jito bundle submission client (HTTP-based, no private crate dependency)
pub struct JitoBundler {
    client: Client,
    config: JitoBundleConfig,
    auth_keypair: Option<Arc<Keypair>>,
}

#[derive(Debug, Serialize)]
struct BundleSubmissionRequest {
    jsonrpc: String,
    id: u64,
    method: String,
    params: [Vec<String>; 1],
}

#[derive(Debug, Deserialize)]
struct BundleSubmissionResponse {
    jsonrpc: String,
    id: u64,
    #[serde(default)]
    result: Option<String>,
    #[serde(default)]
    error: Option<serde_json::Value>,
}

#[derive(Debug, Deserialize)]
struct BundleStatusResponse {
    jsonrpc: String,
    id: u64,
    #[serde(default)]
    result: Option<BundleStatus>,
    #[serde(default)]
    error: Option<serde_json::Value>,
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum BundleStatus {
    Pending { status: String },
    Landed { status: String, slot: u64 },
    Failed { status: String, err: String },
}

impl JitoBundler {
    pub fn new(config: JitoBundleConfig) -> Result<Self> {
        let client = Client::builder()
            .timeout(Duration::from_secs(10))
            .build()
            .context("Failed to create HTTP client")?;

        Ok(Self {
            client,
            config,
            auth_keypair: None,
        })
    }

    pub fn with_auth(mut self, keypair: Keypair) -> Self {
        self.auth_keypair = Some(Arc::new(keypair));
        self
    }

    pub fn load_auth_keypair(&mut self, path: &str) -> Result<()> {
        let content = std::fs::read_to_string(path)
            .with_context(|| format!("Failed to read auth keypair from {}", path))?;
        let bytes: Vec<u8> = serde_json::from_str(&content)
            .with_context(|| "Invalid keypair JSON format")?;
        let keypair = Keypair::from_bytes(&bytes)
            .with_context(|| "Invalid keypair bytes")?;
        self.auth_keypair = Some(Arc::new(keypair));
        Ok(())
    }

    /// Submit a bundle of transactions to Jito block engine
    pub async fn submit_bundle(&self, transactions: &[VersionedTransaction]) -> Result<String> {
        if transactions.is_empty() {
            return Err(anyhow::anyhow!("Empty bundle"));
        }
        if transactions.len() > 5 {
            return Err(anyhow::anyhow!("Bundle too large: max 5 transactions"));
        }

        // Serialize transactions to base64
        let encoded_txs: Vec<String> = transactions
            .iter()
            .map(|tx| {
                let bytes = bincode::serialize(tx).expect("Failed to serialize transaction");
                bs58::encode(bytes).into_string()
            })
            .collect();

        let request = BundleSubmissionRequest {
            jsonrpc: "2.0".to_string(),
            id: rand::random(),
            method: "sendBundle".to_string(),
            params: [encoded_txs],
        };

        let response = self
            .client
            .post(&self.config.block_engine_url)
            .json(&request)
            .send()
            .await
            .context("HTTP request failed")?;

        let status = response.status();
        let body = response.text().await.context("Failed to read response")?;

        if !status.is_success() {
            return Err(anyhow::anyhow!("Jito HTTP error {}: {}", status, body));
        }

        let result: BundleSubmissionResponse = serde_json::from_str(&body)
            .context("Failed to parse Jito response")?;

        if let Some(error) = result.error {
            return Err(anyhow::anyhow!("Jito RPC error: {:?}", error));
        }

        result.result.ok_or_else(|| anyhow::anyhow!("No bundle ID in response"))
    }

    /// Check bundle status by ID
    pub async fn get_bundle_status(&self, bundle_id: &str) -> Result<BundleStatus> {
        let request = serde_json::json!({
            "jsonrpc": "2.0",
            "id": rand::random::<u64>(),
            "method": "getBundleStatuses",
            "params": [[bundle_id]]
        });

        let response = self
            .client
            .post(&self.config.block_engine_url)
            .json(&request)
            .send()
            .await
            .context("HTTP request failed")?;

        let body = response.text().await.context("Failed to read response")?;
        let result: serde_json::Value = serde_json::from_str(&body)
            .context("Failed to parse response")?;

        if let Some(statuses) = result.get("result").and_then(|v| v.get("value")).and_then(|v| v.as_array()) {
            if let Some(first) = statuses.first() {
                return Ok(serde_json::from_value(first.clone())?);
            }
        }

        Err(anyhow::anyhow!("No status found for bundle {}", bundle_id))
    }

    /// Wait for bundle confirmation with timeout
    pub async fn wait_for_confirmation(&self, bundle_id: &str, timeout_secs: u64) -> Result<BundleStatus> {
        let deadline = tokio::time::Instant::now() + Duration::from_secs(timeout_secs);
        
        while tokio::time::Instant::now() < deadline {
            let status = self.get_bundle_status(bundle_id).await?;
            
            match &status {
                BundleStatus::Landed { .. } => return Ok(status),
                BundleStatus::Failed { err, .. } => {
                    return Err(anyhow::anyhow!("Bundle failed: {}", err));
                }
                BundleStatus::Pending { .. } => {
                    tokio::time::sleep(Duration::from_millis(500)).await;
                }
            }
        }

        Err(anyhow::anyhow!("Bundle confirmation timeout"))
    }

    /// Create a signed VersionedTransaction from instructions
    pub fn create_transaction(
        &self,
        instructions: Vec<solana_sdk::instruction::Instruction>,
        recent_blockhash: Hash,
        payer: &Keypair,
    ) -> VersionedTransaction {
        let message = VersionedMessage::V0(
            solana_sdk::message::v0::Message::try_compile(
                &payer.pubkey(),
                &instructions,
                &[],
                recent_blockhash,
            ).expect("Failed to compile message"),
        );
        VersionedTransaction::try_new(message, &[payer]).expect("Failed to create transaction")
    }
}

impl Default for JitoBundler {
    fn default() -> Self {
        Self::new(JitoBundleConfig::default()).expect("Default config")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_bundle_serialization() {
        // Test that bundle request serializes correctly
        let request = BundleSubmissionRequest {
            jsonrpc: "2.0".to_string(),
            id: 1,
            method: "sendBundle".to_string(),
            params: [vec!["test_tx".to_string()]],
        };
        let json = serde_json::to_string(&request).unwrap();
        assert!(json.contains("sendBundle"));
    }
}