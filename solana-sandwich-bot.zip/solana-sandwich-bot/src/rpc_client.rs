//! Minimal async Solana RPC client using reqwest.
//! Avoids pulling in solana-client (and its openssl-sys transitive dep).

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use serde_json::json;
use solana_sdk::{
    commitment_config::{CommitmentConfig, CommitmentLevel},
    hash::Hash,
    pubkey::Pubkey,
    signature::Signature,
};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

/// Minimal async RPC client. Talks JSON-RPC over HTTP via reqwest (rustls).
#[derive(Clone)]
pub struct RpcClient {
    http: reqwest::Client,
    url: Arc<String>,
    commitment: CommitmentConfig,
    next_id: Arc<AtomicU64>,
}

#[derive(Debug, Deserialize)]
struct RpcResponse<T> {
    #[serde(default)]
    result: Option<T>,
    #[serde(default)]
    error: Option<RpcError>,
}

#[derive(Debug, Deserialize)]
struct RpcError {
    code: i64,
    message: String,
}

#[derive(Debug, Deserialize)]
struct LatestBlockhashValue {
    blockhash: String,
}

#[derive(Debug, Deserialize)]
struct LatestBlockhashResult {
    value: LatestBlockhashValue,
}

#[derive(Debug, Deserialize)]
struct AccountInfoValue {
    lamports: u64,
    #[serde(default)]
    data: AccountData,
    #[serde(default)]
    owner: String,
}

#[derive(Debug, Deserialize, Default)]
#[serde(untagged)]
enum AccountData {
    #[default]
    Empty,
    Encoded(String, String),
    #[allow(dead_code)]
    Raw(Vec<u8>),
}

#[derive(Debug, Deserialize)]
struct GetAccountResult {
    value: Option<AccountInfoValue>,
}

#[derive(Debug, Clone)]
pub struct Account {
    pub lamports: u64,
    pub data: Vec<u8>,
    pub owner: Pubkey,
}

impl RpcClient {
    pub fn new_with_commitment(url: String, commitment: CommitmentConfig) -> Self {
        let http = reqwest::Client::builder()
            .timeout(Duration::from_secs(15))
            .build()
            .expect("reqwest client");
        Self {
            http,
            url: Arc::new(url),
            commitment,
            next_id: Arc::new(AtomicU64::new(1)),
        }
    }

    async fn call<T: for<'de> Deserialize<'de>>(
        &self,
        method: &str,
        params: serde_json::Value,
    ) -> Result<T> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let req = json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": method,
            "params": params,
        });

        let resp = self
            .http
            .post(self.url.as_str())
            .json(&req)
            .send()
            .await
            .with_context(|| format!("RPC {} request failed", method))?;

        let status = resp.status();
        let body = resp.text().await.context("Failed to read RPC response body")?;
        if !status.is_success() {
            anyhow::bail!("RPC HTTP {}: {}", status, body);
        }

        let parsed: RpcResponse<T> = serde_json::from_str(&body)
            .with_context(|| format!("Failed to parse RPC {} response", method))?;

        if let Some(err) = parsed.error {
            anyhow::bail!("RPC error {}: {}", err.code, err.message);
        }

        parsed
            .result
            .ok_or_else(|| anyhow::anyhow!("Empty RPC result for {}", method))
    }

    fn commitment_str(&self) -> &'static str {
        match self.commitment.commitment {
            CommitmentLevel::Processed => "processed",
            CommitmentLevel::Confirmed => "confirmed",
            CommitmentLevel::Finalized => "finalized",
            _ => "finalized",
        }
    }

    pub async fn get_slot(&self) -> Result<u64> {
        let params = json!([{"commitment": self.commitment_str()}]);
        self.call("getSlot", params).await
    }

    pub async fn get_latest_blockhash(&self) -> Result<Hash> {
        let params = json!([{"commitment": self.commitment_str()}]);
        let res: LatestBlockhashResult = self.call("getLatestBlockhash", params).await?;
        res.value
            .blockhash
            .parse()
            .with_context(|| "Invalid blockhash returned by RPC")
    }

    /// Fetch raw account data (base64).
    pub async fn get_account(&self, pubkey: &Pubkey) -> Result<Account> {
        let params = json!([
            pubkey.to_string(),
            {
                "encoding": "base64",
                "commitment": self.commitment_str(),
            }
        ]);
        let res: GetAccountResult = self.call("getAccountInfo", params).await?;
        let value = res
            .value
            .ok_or_else(|| anyhow::anyhow!("Account not found: {}", pubkey))?;

        let data = match value.data {
            AccountData::Encoded(b64, _encoding) => {
                use base64::Engine;
                base64::engine::general_purpose::STANDARD
                    .decode(&b64)
                    .context("Failed to decode account data")?
            }
            AccountData::Raw(b) => b,
            AccountData::Empty => Vec::new(),
        };

        let owner: Pubkey = value
            .owner
            .parse()
            .context("Invalid owner pubkey from RPC")?;

        Ok(Account {
            lamports: value.lamports,
            data,
            owner,
        })
    }

    /// Fetch minimum balance for rent exemption for an account of `len` bytes.
    #[allow(dead_code)]
    pub async fn get_minimum_balance_for_rent_exemption(&self, len: usize) -> Result<u64> {
        let params = json!([len]);
        self.call("getMinimumBalanceForRentExemption", params).await
    }
}

/// Trait alias to keep code compatible with Arc<RpcClient> patterns.
pub type SharedRpcClient = Arc<RpcClient>;

/// Signature parse helper kept here to mirror solana-client ergonomics.
#[allow(dead_code)]
pub fn parse_signature(s: &str) -> Result<Signature> {
    s.parse().with_context(|| "Invalid signature")
}

/// Otherwise-unused Serialize import to keep parity with older module surface.
#[allow(dead_code)]
fn _unused(_: &dyn Serialize) {}
